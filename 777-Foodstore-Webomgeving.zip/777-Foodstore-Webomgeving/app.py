from flask import Flask, render_template, request, redirect, url_for, flash
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from models import db, User, TimeEntry

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///company.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Login ongeldig. Probeer opnieuw.', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'admin':
        users = User.query.all()
        time_entries = TimeEntry.query.all()
        return render_template('admin_dashboard.html', users=users, time_entries=time_entries)
    else:
        time_entries = TimeEntry.query.filter_by(user_id=current_user.id).all()
        return render_template('employee_dashboard.html', time_entries=time_entries)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')
        role = 'employee'  # Default role
        new_user = User(username=username, password=password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Registratie succesvol!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/add_time', methods=['GET', 'POST'])
@login_required
def add_time():
    if request.method == 'POST':
        hours = request.form['hours']
        date = request.form['date']
        new_entry = TimeEntry(user_id=current_user.id, hours=hours, date=date)
        db.session.add(new_entry)
        db.session.commit()
        flash('Uren succesvol toegevoegd!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('add_time.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)